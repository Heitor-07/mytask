function cadastrado(){
    window.alert('Cadastro confirmado!');
}

function alteracao(){
    window.alert('Alteração salva!');
}


